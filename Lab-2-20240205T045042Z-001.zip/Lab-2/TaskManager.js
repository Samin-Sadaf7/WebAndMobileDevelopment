'use strict'
class TaskManager {
    constructor(tasksInfo, id, callback) {
      this.id = id;
      this.callback = callback;
      this.tasks = tasksInfo
    }
    
    render(date) {
		
	}

}